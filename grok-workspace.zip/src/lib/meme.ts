export type BlockId = "top" | "bottom";
export type InkId = "paper" | "ink" | "yolk" | "signal";
export type LayoutId =
  | "classic"
  | "poster"
  | "center"
  | "subtitles"
  | "header"
  | "versus"
  | "whisper";

export const INK_HEX: Record<InkId, string> = {
  paper: "#f7f1e6",
  ink: "#16130f",
  yolk: "#f5c518",
  signal: "#ff4d1c",
};

export const INKS: { id: InkId; label: string }[] = [
  { id: "paper", label: "Paper" },
  { id: "ink", label: "Ink" },
  { id: "yolk", label: "Yolk" },
  { id: "signal", label: "Signal" },
];

export const SWATCH_CLASS: Record<InkId, string> = {
  paper: "bg-paper",
  ink: "bg-ink",
  yolk: "bg-yolk",
  signal: "bg-accent",
};

type LayoutSpec = {
  label: string;
  blurb: string;
  fontSize: number;
  outline: number;
  uppercase: boolean;
  top: { x: number; y: number };
  bottom: { x: number; y: number };
};

export const LAYOUTS: Record<LayoutId, LayoutSpec> = {
  classic: {
    label: "Classic",
    blurb: "Top and bottom",
    fontSize: 68,
    outline: 9,
    uppercase: true,
    top: { x: 0.5, y: 0.13 },
    bottom: { x: 0.5, y: 0.87 },
  },
  poster: {
    label: "Poster",
    blurb: "One huge centered line",
    fontSize: 112,
    outline: 12,
    uppercase: true,
    top: { x: 0.5, y: 0.4 },
    bottom: { x: 0.5, y: 0.62 },
  },
  center: {
    label: "Center",
    blurb: "Both lines in the middle",
    fontSize: 76,
    outline: 10,
    uppercase: true,
    top: { x: 0.5, y: 0.4 },
    bottom: { x: 0.5, y: 0.58 },
  },
  subtitles: {
    label: "Subtitles",
    blurb: "Stacked along the bottom",
    fontSize: 52,
    outline: 8,
    uppercase: true,
    top: { x: 0.5, y: 0.74 },
    bottom: { x: 0.5, y: 0.88 },
  },
  header: {
    label: "Header",
    blurb: "Stacked along the top",
    fontSize: 52,
    outline: 8,
    uppercase: true,
    top: { x: 0.5, y: 0.12 },
    bottom: { x: 0.5, y: 0.26 },
  },
  versus: {
    label: "Versus",
    blurb: "Left setup, right punchline",
    fontSize: 48,
    outline: 8,
    uppercase: true,
    top: { x: 0.26, y: 0.5 },
    bottom: { x: 0.74, y: 0.5 },
  },
  whisper: {
    label: "Whisper",
    blurb: "Small type, thin outline",
    fontSize: 32,
    outline: 2,
    uppercase: false,
    top: { x: 0.5, y: 0.1 },
    bottom: { x: 0.5, y: 0.9 },
  },
};

export const LAYOUT_LIST = Object.entries(LAYOUTS).map(([id, spec]) => ({
  id: id as LayoutId,
  ...spec,
}));

export const TEMPLATES = [
  { id: "cat", kind: "photo", name: "Night shift", src: "/templates/night-shift.jpg" },
  { id: "meeting", kind: "photo", name: "The meeting", src: "/templates/the-meeting.jpg" },
  { id: "diner", kind: "photo", name: "Last booth", src: "/templates/last-booth.jpg" },
  { id: "orbit", kind: "photo", name: "Lunch orbit", src: "/templates/lunch-orbit.jpg" },
  { id: "ink", kind: "plate", name: "Ink" },
  { id: "newsprint", kind: "plate", name: "Newsprint" },
  { id: "split", kind: "plate", name: "Split" },
  { id: "signal", kind: "plate", name: "Signal" },
] as const;

export type Template = (typeof TEMPLATES)[number];
export type PlateId = Extract<Template, { kind: "plate" }>["id"];

export type EditorState = {
  top: string;
  bottom: string;
  topX: number;
  topY: number;
  bottomX: number;
  bottomY: number;
  fontSize: number;
  outline: number;
  fill: InkId;
  stroke: InkId;
  uppercase: boolean;
  layout: LayoutId | null;
  templateId: string;
};

const classic = LAYOUTS.classic;

export const INITIAL_EDITOR: EditorState = {
  top: "ONE MORE LOOK",
  bottom: "I HAVE CONCERNS",
  topX: classic.top.x,
  topY: classic.top.y,
  bottomX: classic.bottom.x,
  bottomY: classic.bottom.y,
  fontSize: classic.fontSize,
  outline: classic.outline,
  fill: "paper",
  stroke: "ink",
  uppercase: true,
  layout: "classic",
  templateId: "cat",
};

export function findTemplate(id: string): Template {
  return TEMPLATES.find((item) => item.id === id) ?? TEMPLATES[0];
}

export function applyLayout(state: EditorState, id: LayoutId): EditorState {
  const layout = LAYOUTS[id];
  return {
    ...state,
    layout: id,
    fontSize: layout.fontSize,
    outline: layout.outline,
    uppercase: layout.uppercase,
    topX: layout.top.x,
    topY: layout.top.y,
    bottomX: layout.bottom.x,
    bottomY: layout.bottom.y,
  };
}

export function resetEditor(state: EditorState): EditorState {
  return { ...INITIAL_EDITOR, templateId: state.templateId };
}

const STORAGE_KEY = "caption-press-v1";

function clamp(n: number, min: number, max: number) {
  return Math.min(max, Math.max(min, n));
}

function isInk(value: unknown): value is InkId {
  return value === "paper" || value === "ink" || value === "yolk" || value === "signal";
}

function isLayout(value: unknown): value is LayoutId {
  return typeof value === "string" && value in LAYOUTS;
}

export function readSaved(): EditorState | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    const data = JSON.parse(raw) as Partial<EditorState>;
    if (!data || typeof data !== "object") return null;
    const templateId =
      typeof data.templateId === "string" && TEMPLATES.some((item) => item.id === data.templateId)
        ? data.templateId
        : INITIAL_EDITOR.templateId;
    return {
      top: typeof data.top === "string" ? data.top.slice(0, 180) : INITIAL_EDITOR.top,
      bottom: typeof data.bottom === "string" ? data.bottom.slice(0, 180) : INITIAL_EDITOR.bottom,
      topX: clamp(typeof data.topX === "number" ? data.topX : INITIAL_EDITOR.topX, 0, 1),
      topY: clamp(typeof data.topY === "number" ? data.topY : INITIAL_EDITOR.topY, 0, 1),
      bottomX: clamp(typeof data.bottomX === "number" ? data.bottomX : INITIAL_EDITOR.bottomX, 0, 1),
      bottomY: clamp(typeof data.bottomY === "number" ? data.bottomY : INITIAL_EDITOR.bottomY, 0, 1),
      fontSize: clamp(typeof data.fontSize === "number" ? data.fontSize : INITIAL_EDITOR.fontSize, 20, 130),
      outline: clamp(typeof data.outline === "number" ? data.outline : INITIAL_EDITOR.outline, 0, 28),
      fill: isInk(data.fill) ? data.fill : INITIAL_EDITOR.fill,
      stroke: isInk(data.stroke) ? data.stroke : INITIAL_EDITOR.stroke,
      uppercase: typeof data.uppercase === "boolean" ? data.uppercase : INITIAL_EDITOR.uppercase,
      layout: data.layout === null ? null : isLayout(data.layout) ? data.layout : INITIAL_EDITOR.layout,
      templateId,
    };
  } catch {
    return null;
  }
}

export function writeSaved(state: EditorState) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch {
    /* Private mode or a full disk — the editor still works for this visit. */
  }
}

export type TextBox = {
  id: BlockId;
  left: number;
  top: number;
  width: number;
  height: number;
  cx: number;
  cy: number;
};

export type RenderInput = {
  image: HTMLImageElement | null;
  plate: PlateId | null;
  topText: string;
  bottomText: string;
  topX: number;
  topY: number;
  bottomX: number;
  bottomY: number;
  fontSize: number;
  outline: number;
  fill: string;
  stroke: string;
  uppercase: boolean;
  editing: boolean;
  active: BlockId | null;
};

const MAX_EDGE = 1400;

function canvasSize(image: HTMLImageElement | null) {
  if (image && image.naturalWidth > 0 && image.naturalHeight > 0) {
    const scale = Math.min(1, MAX_EDGE / Math.max(image.naturalWidth, image.naturalHeight));
    return {
      w: Math.max(2, Math.round(image.naturalWidth * scale)),
      h: Math.max(2, Math.round(image.naturalHeight * scale)),
    };
  }
  return { w: 1080, h: 1080 };
}

function wrapLines(ctx: CanvasRenderingContext2D, text: string, maxWidth: number) {
  const words = text.split(" ");
  const lines: string[] = [];
  let line = "";
  for (const word of words) {
    const trial = line ? `${line} ${word}` : word;
    if (!line || ctx.measureText(trial).width <= maxWidth) line = trial;
    else {
      lines.push(line);
      line = word;
    }
  }
  if (line) lines.push(line);
  return lines;
}

function withAlpha(hex: string, alpha: number) {
  const n = hex.replace("#", "");
  const r = Number.parseInt(n.slice(0, 2), 16);
  const g = Number.parseInt(n.slice(2, 4), 16);
  const b = Number.parseInt(n.slice(4, 6), 16);
  return `rgba(${r}, ${g}, ${b}, ${alpha})`;
}

function paintPlate(ctx: CanvasRenderingContext2D, plate: PlateId, w: number, h: number) {
  if (plate === "ink") {
    const glow = ctx.createRadialGradient(w / 2, h * 0.46, w * 0.08, w / 2, h / 2, w * 0.75);
    glow.addColorStop(0, "#2c261f");
    glow.addColorStop(1, "#100e0c");
    ctx.fillStyle = glow;
    ctx.fillRect(0, 0, w, h);
    return;
  }
  if (plate === "newsprint") {
    ctx.fillStyle = "#f3ecdf";
    ctx.fillRect(0, 0, w, h);
    ctx.fillStyle = "rgba(22, 19, 15, 0.07)";
    const step = Math.max(10, Math.round(w / 70));
    const radius = Math.max(1.1, w / 420);
    for (let y = step; y < h; y += step) {
      const offset = (y / step) % 2 === 0 ? step : step * 1.5;
      for (let x = offset; x < w; x += step * 2) {
        ctx.beginPath();
        ctx.arc(x, y, radius, 0, Math.PI * 2);
        ctx.fill();
      }
    }
    return;
  }
  if (plate === "split") {
    ctx.fillStyle = "#16130f";
    ctx.fillRect(0, 0, w / 2, h);
    ctx.fillStyle = "#f3ecdf";
    ctx.fillRect(w / 2, 0, w / 2, h);
    const bar = Math.max(8, w * 0.014);
    ctx.fillStyle = "#ff4d1c";
    ctx.fillRect(w / 2 - bar / 2, 0, bar, h);
    return;
  }
  ctx.fillStyle = "#ff4d1c";
  ctx.fillRect(0, 0, w, h);
  const margin = w * 0.055;
  ctx.strokeStyle = "#16130f";
  ctx.lineWidth = Math.max(10, w * 0.02);
  ctx.strokeRect(margin, margin, w - margin * 2, h - margin * 2);
}

function paintBlock(
  ctx: CanvasRenderingContext2D,
  input: RenderInput,
  id: BlockId,
  raw: string,
  nx: number,
  ny: number,
  w: number,
  h: number,
): TextBox | null {
  const ghost = input.editing && raw.trim().length === 0;
  const source = ghost ? (id === "top" ? "Top text" : "Bottom text") : raw.trim();
  if (!source) return null;
  const shown = (input.uppercase ? source.toUpperCase() : source).replace(/\s+/g, " ").trim();
  if (!shown) return null;

  const scale = w / 1000;
  const size = Math.max(14, input.fontSize * scale);
  const edge = Math.min(nx, 1 - nx);
  const maxWidth = clamp(edge * 2 * w - w * 0.06, w * 0.3, w * 0.9);
  ctx.font = `400 ${size}px Anton, "Arial Black", Impact, sans-serif`;
  if ("letterSpacing" in ctx) ctx.letterSpacing = `${Math.max(0, size * 0.015)}px`;
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  const lines = wrapLines(ctx, shown, maxWidth);
  const lineHeight = size * 1.12;
  const blockHeight = lines.length * lineHeight;
  let blockWidth = 0;
  for (const line of lines) blockWidth = Math.max(blockWidth, ctx.measureText(line).width);

  const cx = clamp(nx, 0, 1) * w;
  const cy = clamp(ny, 0, 1) * h;
  ctx.lineJoin = "round";
  ctx.miterLimit = 2;
  ctx.lineWidth = Math.max(0, input.outline * scale * 2);
  ctx.fillStyle = withAlpha(input.fill, ghost ? 0.45 : 1);
  ctx.strokeStyle = withAlpha(input.stroke, ghost ? 0.55 : 1);

  lines.forEach((line, index) => {
    const ly = cy - blockHeight / 2 + lineHeight * index + lineHeight / 2;
    if (input.outline > 0) ctx.strokeText(line, cx, ly);
    ctx.fillText(line, cx, ly);
  });

  if (input.editing && input.active === id) {
    ctx.save();
    ctx.strokeStyle = "#ff4d1c";
    ctx.lineWidth = Math.max(2, scale * 2);
    ctx.setLineDash([scale * 8, scale * 6]);
    const pad = size * 0.2;
    ctx.strokeRect(cx - blockWidth / 2 - pad, cy - blockHeight / 2 - pad, blockWidth + pad * 2, blockHeight + pad * 2);
    ctx.restore();
  }

  return {
    id,
    left: cx - blockWidth / 2,
    top: cy - blockHeight / 2,
    width: blockWidth,
    height: blockHeight,
    cx: cx / w,
    cy: cy / h,
  };
}

export function renderMeme(canvas: HTMLCanvasElement, input: RenderInput): TextBox[] {
  const { w, h } = canvasSize(input.plate ? null : input.image);
  if (canvas.width !== w) canvas.width = w;
  if (canvas.height !== h) canvas.height = h;
  const ctx = canvas.getContext("2d");
  if (!ctx) return [];
  ctx.clearRect(0, 0, w, h);
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = "high";

  if (input.image && !input.plate) {
    ctx.drawImage(input.image, 0, 0, w, h);
  } else {
    paintPlate(ctx, input.plate ?? "ink", w, h);
  }

  ctx.save();
  ctx.beginPath();
  ctx.rect(0, 0, w, h);
  ctx.clip();
  const boxes = [
    paintBlock(ctx, input, "top", input.topText, input.topX, input.topY, w, h),
    paintBlock(ctx, input, "bottom", input.bottomText, input.bottomX, input.bottomY, w, h),
  ].filter((box): box is TextBox => box !== null);
  ctx.restore();
  return boxes;
}

export function hitTest(boxes: TextBox[], px: number, py: number, pad: number, prefer: BlockId | null) {
  const hits = boxes.filter(
    (box) =>
      px >= box.left - pad &&
      px <= box.left + box.width + pad &&
      py >= box.top - pad &&
      py <= box.top + box.height + pad,
  );
  if (hits.length === 0) return null;
  return hits.find((box) => box.id === prefer) ?? hits[hits.length - 1];
}

export function downloadMeme(input: RenderInput) {
  const canvas = document.createElement("canvas");
  renderMeme(canvas, { ...input, editing: false, active: null });
  const href = canvas.toDataURL("image/png");
  const link = document.createElement("a");
  link.href = href;
  link.download = "caption-press.png";
  document.body.appendChild(link);
  link.click();
  link.remove();
}
