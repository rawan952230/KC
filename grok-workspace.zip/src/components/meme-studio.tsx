import { useEffect, useId, useRef, useState } from "react";
import { Download, ImagePlus, RotateCcw } from "lucide-react";
import { cn } from "@/lib/cn";
import {
  INKS,
  INK_HEX,
  INITIAL_EDITOR,
  LAYOUT_LIST,
  SWATCH_CLASS,
  applyLayout,
  downloadMeme,
  findTemplate,
  hitTest,
  readSaved,
  renderMeme,
  resetEditor,
  writeSaved,
  type BlockId,
  type EditorState,
  type InkId,
  type LayoutId,
  type PlateId,
  type RenderInput,
} from "@/lib/meme";

function clamp(n: number, min: number, max: number) {
  return Math.min(max, Math.max(min, n));
}

function oppositeInk(fill: InkId, stroke: InkId): InkId {
  if (fill !== stroke) return stroke;
  return fill === "ink" ? "paper" : "ink";
}

export function MemeStudio() {
  const [editor, setEditor] = useState<EditorState>(INITIAL_EDITOR);
  const [upload, setUpload] = useState<{ url: string; name: string } | null>(null);
  const [image, setImage] = useState<HTMLImageElement | null>(null);
  const [active, setActive] = useState<BlockId>("top");
  const [error, setError] = useState("");
  const [saved, setSaved] = useState(false);
  const [fontTick, setFontTick] = useState(0);
  const [dropOver, setDropOver] = useState(false);
  const [hydrated, setHydrated] = useState(false);

  const canvasRef = useRef<HTMLCanvasElement>(null);
  const boxesRef = useRef<ReturnType<typeof renderMeme>>([]);
  const dragRef = useRef<{ id: BlockId; ox: number; oy: number } | null>(null);
  const dropDepth = useRef(0);
  const uploadUrl = useRef<string | null>(null);
  const topRef = useRef<HTMLInputElement>(null);
  const bottomRef = useRef<HTMLInputElement>(null);
  const topFieldId = useId();
  const bottomFieldId = useId();

  const template = findTemplate(editor.templateId);
  const plate: PlateId | null = !upload && template.kind === "plate" ? template.id : null;
  const src = upload?.url ?? (template.kind === "photo" ? template.src : null);
  const ready = src ? image !== null : true;

  useEffect(() => {
    const savedState = readSaved();
    if (savedState) setEditor(savedState);
    setHydrated(true);
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    writeSaved(editor);
  }, [editor, hydrated]);

  useEffect(() => {
    const kick = () => setFontTick((n) => n + 1);
    document.fonts.ready.then(kick).catch(kick);
    document.fonts.addEventListener("loadingdone", kick);
    return () => document.fonts.removeEventListener("loadingdone", kick);
  }, []);

  useEffect(() => {
    const blockNavigation = (event: DragEvent) => {
      if ([...(event.dataTransfer?.items ?? [])].some((item) => item.kind === "file")) {
        event.preventDefault();
      }
    };
    window.addEventListener("dragover", blockNavigation);
    window.addEventListener("drop", blockNavigation);
    return () => {
      window.removeEventListener("dragover", blockNavigation);
      window.removeEventListener("drop", blockNavigation);
    };
  }, []);

  useEffect(() => {
    return () => {
      if (uploadUrl.current) URL.revokeObjectURL(uploadUrl.current);
    };
  }, []);

  useEffect(() => {
    if (!saved) return;
    const timer = window.setTimeout(() => setSaved(false), 1600);
    return () => window.clearTimeout(timer);
  }, [saved]);

  useEffect(() => {
    if (!src) {
      setImage(null);
      return;
    }
    let cancel = false;
    const next = new Image();
    if (!src.startsWith("blob:")) next.crossOrigin = "anonymous";
    next.onload = () => {
      if (cancel) return;
      setImage(next);
      setError("");
    };
    next.onerror = () => {
      if (cancel) return;
      setImage(null);
      setError("Couldn't load that image. Try a JPG or PNG.");
    };
    next.src = src;
    return () => {
      cancel = true;
    };
  }, [src]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || (src && !image)) return;
    boxesRef.current = renderMeme(canvas, renderInput(true));
  }, [editor, image, plate, src, active, fontTick]);

  function renderInput(editing: boolean): RenderInput {
    return {
      image: plate ? null : image,
      plate,
      topText: editor.top,
      bottomText: editor.bottom,
      topX: editor.topX,
      topY: editor.topY,
      bottomX: editor.bottomX,
      bottomY: editor.bottomY,
      fontSize: editor.fontSize,
      outline: editor.outline,
      fill: INK_HEX[editor.fill],
      stroke: INK_HEX[editor.stroke],
      uppercase: editor.uppercase,
      editing,
      active: editing ? active : null,
    };
  }

  function pointOf(event: React.PointerEvent<HTMLCanvasElement>) {
    const canvas = canvasRef.current;
    const rect = event.currentTarget.getBoundingClientRect();
    const width = rect.width || 1;
    const height = rect.height || 1;
    return {
      px: ((event.clientX - rect.left) / width) * (canvas?.width ?? 1),
      py: ((event.clientY - rect.top) / height) * (canvas?.height ?? 1),
    };
  }

  function onPointerDown(event: React.PointerEvent<HTMLCanvasElement>) {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const point = pointOf(event);
    const pad = Math.max(36, canvas.width * 0.04);
    const hit = hitTest(boxesRef.current, point.px, point.py, pad, active);
    if (!hit) return;
    event.currentTarget.setPointerCapture(event.pointerId);
    dragRef.current = {
      id: hit.id,
      ox: hit.cx - point.px / canvas.width,
      oy: hit.cy - point.py / canvas.height,
    };
    setActive(hit.id);
  }

  function onPointerMove(event: React.PointerEvent<HTMLCanvasElement>) {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const point = pointOf(event);
    const drag = dragRef.current;
    if (!drag) {
      const pad = Math.max(36, canvas.width * 0.04);
      const hit = hitTest(boxesRef.current, point.px, point.py, pad, active);
      canvas.style.cursor = hit ? "grab" : "default";
      return;
    }
    canvas.style.cursor = "grabbing";
    const x = clamp(point.px / canvas.width + drag.ox, 0.04, 0.96);
    const y = clamp(point.py / canvas.height + drag.oy, 0.05, 0.95);
    setEditor((state) => {
      if (drag.id === "top") {
        if (state.topX === x && state.topY === y) return state;
        return { ...state, topX: x, topY: y, layout: null };
      }
      if (state.bottomX === x && state.bottomY === y) return state;
      return { ...state, bottomX: x, bottomY: y, layout: null };
    });
  }

  function onPointerUp(event: React.PointerEvent<HTMLCanvasElement>) {
    dragRef.current = null;
    if (event.currentTarget.hasPointerCapture(event.pointerId)) {
      event.currentTarget.releasePointerCapture(event.pointerId);
    }
    event.currentTarget.style.cursor = "default";
  }

  function onDoubleClick(event: React.PointerEvent<HTMLCanvasElement>) {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const point = pointOf(event);
    const hit = hitTest(boxesRef.current, point.px, point.py, Math.max(36, canvas.width * 0.04), active);
    if (!hit) return;
    (hit.id === "top" ? topRef : bottomRef).current?.focus();
  }

  function takeFile(file: File | undefined) {
    if (!file) return;
    if (!file.type.startsWith("image/")) {
      setError("That file isn't an image.");
      return;
    }
    if (uploadUrl.current) URL.revokeObjectURL(uploadUrl.current);
    const url = URL.createObjectURL(file);
    uploadUrl.current = url;
    setUpload({ url, name: file.name });
    setError("");
  }

  function setFill(fill: InkId) {
    setEditor((state) => ({ ...state, fill, stroke: oppositeInk(fill, state.stroke) }));
  }

  function setStroke(stroke: InkId) {
    setEditor((state) => ({ ...state, stroke, fill: oppositeInk(stroke, state.fill) }));
  }

  function onDownload() {
    if (!ready) return;
    try {
      downloadMeme(renderInput(false));
      setSaved(true);
      setError("");
    } catch {
      setError("Couldn't export that image.");
    }
  }

  const blurb = editor.layout ? LAYOUT_LIST.find((item) => item.id === editor.layout)?.blurb : "Custom size and placement";

  return (
    <div className="min-h-dvh bg-paper text-ink">
      <header className="sticky top-0 z-20 border-b border-ink/10 bg-paper/90 backdrop-blur-md">
        <div className="mx-auto flex max-w-6xl items-center justify-between gap-3 px-4 py-3">
          <div className="min-w-0">
            <h1 className="truncate font-display text-2xl leading-none tracking-wide sm:text-4xl">CAPTION PRESS</h1>
            <p className="mt-1 truncate text-sm text-muted">Top line. Bottom line. Done.</p>
          </div>
          <div className="flex shrink-0 items-center gap-2">
            <button
              type="button"
              aria-label="Reset text and layout"
              onClick={() => setEditor((state) => resetEditor(state))}
              className="inline-flex h-11 items-center gap-2 rounded-md px-3 text-sm font-semibold text-ink transition-colors duration-200 hover:bg-paper-deep"
            >
              <RotateCcw className="size-4" aria-hidden="true" />
              <span className="hidden sm:inline">Reset</span>
            </button>
            <button
              type="button"
              onClick={onDownload}
              disabled={!ready}
              className="inline-flex h-11 items-center gap-2 rounded-md bg-accent px-3 text-sm font-semibold text-ink transition-opacity duration-200 hover:opacity-90 disabled:opacity-40 sm:px-4"
            >
              <Download className="size-4" aria-hidden="true" />
              {saved ? "Saved" : "Download"}
            </button>
          </div>
        </div>
      </header>

      <main className="mx-auto grid w-full min-w-0 max-w-6xl grid-cols-1 gap-6 px-4 py-5 lg:grid-cols-[minmax(0,1.25fr)_minmax(20rem,0.8fr)] lg:items-start lg:px-6">
        <section className="min-w-0">
          <div
            className="relative rounded-lg bg-ink p-2 shadow-lift"
            onDragEnter={(event) => {
              event.preventDefault();
              dropDepth.current += 1;
              setDropOver(true);
            }}
            onDragOver={(event) => event.preventDefault()}
            onDragLeave={() => {
              dropDepth.current -= 1;
              if (dropDepth.current <= 0) {
                dropDepth.current = 0;
                setDropOver(false);
              }
            }}
            onDrop={(event) => {
              event.preventDefault();
              dropDepth.current = 0;
              setDropOver(false);
              takeFile(event.dataTransfer.files?.[0]);
            }}
          >
            <span className="pointer-events-none absolute top-1 left-1 size-1 bg-accent" aria-hidden="true" />
            <span className="pointer-events-none absolute top-1 right-1 size-1 bg-accent" aria-hidden="true" />
            <span className="pointer-events-none absolute bottom-1 left-1 size-1 bg-accent" aria-hidden="true" />
            <span className="pointer-events-none absolute right-1 bottom-1 size-1 bg-accent" aria-hidden="true" />
            <canvas
              ref={canvasRef}
              width={1080}
              height={1080}
              aria-label={`Meme preview. Top: ${editor.top || "empty"}. Bottom: ${editor.bottom || "empty"}.`}
              onPointerDown={onPointerDown}
              onPointerMove={onPointerMove}
              onPointerUp={onPointerUp}
              onPointerCancel={onPointerUp}
              onDoubleClick={onDoubleClick}
              className="meme-canvas rounded-md"
            />
            {dropOver ? (
              <div className="absolute inset-2 grid place-items-center rounded-md bg-ink/80">
                <p className="font-display text-4xl tracking-wide text-paper">DROP IT</p>
              </div>
            ) : null}
          </div>
          <p className="mt-3 text-sm text-muted">Drag either line. Double-tap a line to edit it.</p>

          <div className="mt-5">
            <div className="flex items-baseline justify-between gap-3">
              <h2 className="text-sm font-semibold tracking-wide uppercase">Layout</h2>
              <p className="truncate text-sm text-muted">{blurb}</p>
            </div>
            <div className="mt-2 flex w-full min-w-0 gap-2 overflow-x-auto pb-1">
              {LAYOUT_LIST.map((layout) => (
                <button
                  key={layout.id}
                  type="button"
                  aria-pressed={editor.layout === layout.id}
                  onClick={() => setEditor((state) => applyLayout(state, layout.id as LayoutId))}
                  className={cn(
                    "h-11 shrink-0 rounded-full px-4 text-sm font-semibold transition-colors duration-200",
                    editor.layout === layout.id ? "bg-ink text-paper" : "bg-paper text-ink shadow-border hover:bg-paper-deep",
                  )}
                >
                  {layout.label}
                </button>
              ))}
            </div>
          </div>

          <div className="mt-5">
            <div className="flex items-baseline justify-between gap-3">
              <h2 className="text-sm font-semibold tracking-wide uppercase">Picture</h2>
              <p className="truncate text-sm text-muted">{upload ? upload.name : "Or drop one on the frame"}</p>
            </div>
            <div className="mt-2 flex w-full min-w-0 gap-2 overflow-x-auto pb-1">
              {["cat", "meeting", "diner", "orbit", "ink", "newsprint", "split", "signal"].map((id) => {
                const item = findTemplate(id);
                const selected = !upload && editor.templateId === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    aria-pressed={selected}
                    aria-label={item.name}
                    onClick={() => {
                      setUpload(null);
                      if (uploadUrl.current) {
                        URL.revokeObjectURL(uploadUrl.current);
                        uploadUrl.current = null;
                      }
                      setEditor((state) => ({ ...state, templateId: item.id }));
                    }}
                    className={cn(
                      "w-20 shrink-0 rounded-sm p-1 text-left",
                      selected ? "bg-ink text-paper" : "text-ink",
                    )}
                  >
                    <span className="block aspect-square overflow-hidden rounded-sm outline outline-1 -outline-offset-1 outline-ink/15">
                      {item.kind === "photo" ? (
                        <img src={item.src} alt="" draggable={false} className="size-full object-cover" />
                      ) : (
                        <PlateThumb id={item.id} />
                      )}
                    </span>
                    <span className="mt-1 block truncate text-xs font-medium">{item.name}</span>
                  </button>
                );
              })}
              <label className="relative flex w-20 shrink-0 cursor-pointer flex-col items-center justify-center gap-1 rounded-sm bg-ink p-1 text-center text-xs font-semibold text-paper">
                <ImagePlus className="size-5" aria-hidden="true" />
                Upload
                <input
                  type="file"
                  accept="image/png,image/jpeg,image/webp,image/gif"
                  className="absolute inset-0 cursor-pointer opacity-0"
                  onChange={(event) => {
                    takeFile(event.target.files?.[0]);
                    event.target.value = "";
                  }}
                />
              </label>
            </div>
            {error ? (
              <p role="alert" className="mt-2 text-sm font-medium text-accent">
                {error}
              </p>
            ) : null}
          </div>
        </section>

        <aside className="studio-panel flex min-w-0 flex-col gap-6">
          <div className="flex flex-col gap-3">
            <h2 className="text-sm font-semibold tracking-wide uppercase">The lines</h2>
            <label htmlFor={topFieldId} className="flex flex-col gap-1.5">
              <span className="text-sm font-medium">Top line</span>
              <input
                ref={topRef}
                id={topFieldId}
                value={editor.top}
                maxLength={180}
                placeholder="When it finally works"
                onFocus={() => setActive("top")}
                onChange={(event) => setEditor((state) => ({ ...state, top: event.target.value }))}
                className={cn(
                  "h-12 w-full rounded-md bg-paper px-3 text-base text-ink shadow-border outline-none placeholder:text-muted/70",
                  active === "top" ? "ring-2 ring-accent" : "focus-visible:ring-2 focus-visible:ring-accent",
                )}
              />
            </label>
            <label htmlFor={bottomFieldId} className="flex flex-col gap-1.5">
              <span className="text-sm font-medium">Bottom line</span>
              <input
                ref={bottomRef}
                id={bottomFieldId}
                value={editor.bottom}
                maxLength={180}
                placeholder="And nobody saw it"
                onFocus={() => setActive("bottom")}
                onChange={(event) => setEditor((state) => ({ ...state, bottom: event.target.value }))}
                className={cn(
                  "h-12 w-full rounded-md bg-paper px-3 text-base text-ink shadow-border outline-none placeholder:text-muted/70",
                  active === "bottom" ? "ring-2 ring-accent" : "focus-visible:ring-2 focus-visible:ring-accent",
                )}
              />
            </label>
          </div>

          <div className="flex flex-col gap-4">
            <h2 className="text-sm font-semibold tracking-wide uppercase">Type</h2>
            <Slider
              label="Font size"
              value={editor.fontSize}
              min={20}
              max={130}
              onChange={(fontSize) => setEditor((state) => ({ ...state, fontSize, layout: null }))}
            />
            <Slider
              label="Outline"
              value={editor.outline}
              min={0}
              max={28}
              onChange={(outline) => setEditor((state) => ({ ...state, outline, layout: null }))}
            />
            {editor.outline === 0 ? (
              <p className="text-sm text-muted">No outline — busy photos will swallow the words.</p>
            ) : null}
            <button
              type="button"
              aria-pressed={editor.uppercase}
              onClick={() => setEditor((state) => ({ ...state, uppercase: !state.uppercase, layout: null }))}
              className={cn(
                "h-11 rounded-md px-4 text-sm font-semibold transition-colors duration-200",
                editor.uppercase ? "bg-ink text-paper" : "bg-paper text-ink shadow-border",
              )}
            >
              {editor.uppercase ? "ALL CAPS" : "As typed"}
            </button>
            <Swatches label="Fill" value={editor.fill} onChange={setFill} />
            <Swatches label="Outline color" value={editor.stroke} onChange={setStroke} />
          </div>
        </aside>
      </main>

      <footer className="mx-auto max-w-6xl px-4 pb-10 text-sm text-muted lg:px-6">
        Drag the lines. Download a PNG. Nothing leaves this page.
      </footer>
      <p className="sr-only" aria-live="polite">
        {saved ? "Image downloaded." : ""}
      </p>
    </div>
  );
}

function Slider({
  label,
  value,
  min,
  max,
  onChange,
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  onChange: (value: number) => void;
}) {
  const id = useId();
  return (
    <div className="flex flex-col gap-1">
      <div className="flex items-baseline justify-between">
        <label htmlFor={id} className="text-sm font-medium">
          {label}
        </label>
        <span className="text-sm font-semibold tabular-nums">{value}</span>
      </div>
      <input
        id={id}
        type="range"
        min={min}
        max={max}
        step={1}
        value={value}
        aria-valuetext={`${value}`}
        onChange={(event) => onChange(Number(event.target.value))}
        className="h-11 w-full cursor-pointer accent-ink"
      />
    </div>
  );
}

function Swatches({ label, value, onChange }: { label: string; value: InkId; onChange: (ink: InkId) => void }) {
  return (
    <div className="flex items-center justify-between gap-3">
      <span className="text-sm font-medium">{label}</span>
      <div className="flex gap-2">
        {INKS.map((ink) => {
          const selected = value === ink.id;
          return (
            <button
              key={ink.id}
              type="button"
              aria-label={`${label} ${ink.label}`}
              aria-pressed={selected}
              onClick={() => onChange(ink.id)}
              className={cn(
                "size-11 rounded-full shadow-border",
                SWATCH_CLASS[ink.id],
                selected && (ink.id === "signal" ? "ring-2 ring-ink ring-offset-2 ring-offset-paper" : "ring-2 ring-accent ring-offset-2 ring-offset-paper"),
              )}
            />
          );
        })}
      </div>
    </div>
  );
}

function PlateThumb({ id }: { id: PlateId }) {
  if (id === "ink") return <span className="block size-full bg-ink-soft" />;
  if (id === "newsprint") return <span className="block size-full bg-paper" />;
  if (id === "signal") return <span className="block size-full bg-accent" />;
  return (
    <span className="flex size-full">
      <span className="h-full w-1/2 bg-ink" />
      <span className="h-full w-1 bg-accent" />
      <span className="h-full flex-1 bg-paper" />
    </span>
  );
}
