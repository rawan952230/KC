import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as Download, n as RotateCcw, r as ImagePlus } from "../_libs/lucide-react.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BdZlvSIw.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var INK_HEX = {
	paper: "#f7f1e6",
	ink: "#16130f",
	yolk: "#f5c518",
	signal: "#ff4d1c"
};
var INKS = [
	{
		id: "paper",
		label: "Paper"
	},
	{
		id: "ink",
		label: "Ink"
	},
	{
		id: "yolk",
		label: "Yolk"
	},
	{
		id: "signal",
		label: "Signal"
	}
];
var SWATCH_CLASS = {
	paper: "bg-paper",
	ink: "bg-ink",
	yolk: "bg-yolk",
	signal: "bg-accent"
};
var LAYOUTS = {
	classic: {
		label: "Classic",
		blurb: "Top and bottom",
		fontSize: 68,
		outline: 9,
		uppercase: true,
		top: {
			x: .5,
			y: .13
		},
		bottom: {
			x: .5,
			y: .87
		}
	},
	poster: {
		label: "Poster",
		blurb: "One huge centered line",
		fontSize: 112,
		outline: 12,
		uppercase: true,
		top: {
			x: .5,
			y: .4
		},
		bottom: {
			x: .5,
			y: .62
		}
	},
	center: {
		label: "Center",
		blurb: "Both lines in the middle",
		fontSize: 76,
		outline: 10,
		uppercase: true,
		top: {
			x: .5,
			y: .4
		},
		bottom: {
			x: .5,
			y: .58
		}
	},
	subtitles: {
		label: "Subtitles",
		blurb: "Stacked along the bottom",
		fontSize: 52,
		outline: 8,
		uppercase: true,
		top: {
			x: .5,
			y: .74
		},
		bottom: {
			x: .5,
			y: .88
		}
	},
	header: {
		label: "Header",
		blurb: "Stacked along the top",
		fontSize: 52,
		outline: 8,
		uppercase: true,
		top: {
			x: .5,
			y: .12
		},
		bottom: {
			x: .5,
			y: .26
		}
	},
	versus: {
		label: "Versus",
		blurb: "Left setup, right punchline",
		fontSize: 48,
		outline: 8,
		uppercase: true,
		top: {
			x: .26,
			y: .5
		},
		bottom: {
			x: .74,
			y: .5
		}
	},
	whisper: {
		label: "Whisper",
		blurb: "Small type, thin outline",
		fontSize: 32,
		outline: 2,
		uppercase: false,
		top: {
			x: .5,
			y: .1
		},
		bottom: {
			x: .5,
			y: .9
		}
	}
};
var LAYOUT_LIST = Object.entries(LAYOUTS).map(([id, spec]) => ({
	id,
	...spec
}));
var TEMPLATES = [
	{
		id: "cat",
		kind: "photo",
		name: "Night shift",
		src: "/templates/night-shift.jpg"
	},
	{
		id: "meeting",
		kind: "photo",
		name: "The meeting",
		src: "/templates/the-meeting.jpg"
	},
	{
		id: "diner",
		kind: "photo",
		name: "Last booth",
		src: "/templates/last-booth.jpg"
	},
	{
		id: "orbit",
		kind: "photo",
		name: "Lunch orbit",
		src: "/templates/lunch-orbit.jpg"
	},
	{
		id: "ink",
		kind: "plate",
		name: "Ink"
	},
	{
		id: "newsprint",
		kind: "plate",
		name: "Newsprint"
	},
	{
		id: "split",
		kind: "plate",
		name: "Split"
	},
	{
		id: "signal",
		kind: "plate",
		name: "Signal"
	}
];
var classic = LAYOUTS.classic;
var INITIAL_EDITOR = {
	top: "ONE MORE LOOK",
	bottom: "I HAVE CONCERNS",
	topX: classic.top.x,
	topY: classic.top.y,
	bottomX: classic.bottom.x,
	bottomY: classic.bottom.y,
	fontSize: classic.fontSize,
	outline: classic.outline,
	fill: "paper",
	stroke: "ink",
	uppercase: true,
	layout: "classic",
	templateId: "cat"
};
function findTemplate(id) {
	return TEMPLATES.find((item) => item.id === id) ?? TEMPLATES[0];
}
function applyLayout(state, id) {
	const layout = LAYOUTS[id];
	return {
		...state,
		layout: id,
		fontSize: layout.fontSize,
		outline: layout.outline,
		uppercase: layout.uppercase,
		topX: layout.top.x,
		topY: layout.top.y,
		bottomX: layout.bottom.x,
		bottomY: layout.bottom.y
	};
}
function resetEditor(state) {
	return {
		...INITIAL_EDITOR,
		templateId: state.templateId
	};
}
var STORAGE_KEY = "caption-press-v1";
function clamp$1(n, min, max) {
	return Math.min(max, Math.max(min, n));
}
function isInk(value) {
	return value === "paper" || value === "ink" || value === "yolk" || value === "signal";
}
function isLayout(value) {
	return typeof value === "string" && value in LAYOUTS;
}
function readSaved() {
	try {
		const raw = localStorage.getItem(STORAGE_KEY);
		if (!raw) return null;
		const data = JSON.parse(raw);
		if (!data || typeof data !== "object") return null;
		const templateId = typeof data.templateId === "string" && TEMPLATES.some((item) => item.id === data.templateId) ? data.templateId : INITIAL_EDITOR.templateId;
		return {
			top: typeof data.top === "string" ? data.top.slice(0, 180) : INITIAL_EDITOR.top,
			bottom: typeof data.bottom === "string" ? data.bottom.slice(0, 180) : INITIAL_EDITOR.bottom,
			topX: clamp$1(typeof data.topX === "number" ? data.topX : INITIAL_EDITOR.topX, 0, 1),
			topY: clamp$1(typeof data.topY === "number" ? data.topY : INITIAL_EDITOR.topY, 0, 1),
			bottomX: clamp$1(typeof data.bottomX === "number" ? data.bottomX : INITIAL_EDITOR.bottomX, 0, 1),
			bottomY: clamp$1(typeof data.bottomY === "number" ? data.bottomY : INITIAL_EDITOR.bottomY, 0, 1),
			fontSize: clamp$1(typeof data.fontSize === "number" ? data.fontSize : INITIAL_EDITOR.fontSize, 20, 130),
			outline: clamp$1(typeof data.outline === "number" ? data.outline : INITIAL_EDITOR.outline, 0, 28),
			fill: isInk(data.fill) ? data.fill : INITIAL_EDITOR.fill,
			stroke: isInk(data.stroke) ? data.stroke : INITIAL_EDITOR.stroke,
			uppercase: typeof data.uppercase === "boolean" ? data.uppercase : INITIAL_EDITOR.uppercase,
			layout: data.layout === null ? null : isLayout(data.layout) ? data.layout : INITIAL_EDITOR.layout,
			templateId
		};
	} catch {
		return null;
	}
}
function writeSaved(state) {
	try {
		localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
	} catch {}
}
var MAX_EDGE = 1400;
function canvasSize(image) {
	if (image && image.naturalWidth > 0 && image.naturalHeight > 0) {
		const scale = Math.min(1, MAX_EDGE / Math.max(image.naturalWidth, image.naturalHeight));
		return {
			w: Math.max(2, Math.round(image.naturalWidth * scale)),
			h: Math.max(2, Math.round(image.naturalHeight * scale))
		};
	}
	return {
		w: 1080,
		h: 1080
	};
}
function wrapLines(ctx, text, maxWidth) {
	const words = text.split(" ");
	const lines = [];
	let line = "";
	for (const word of words) {
		const trial = line ? `${line} ${word}` : word;
		if (!line || ctx.measureText(trial).width <= maxWidth) line = trial;
		else {
			lines.push(line);
			line = word;
		}
	}
	if (line) lines.push(line);
	return lines;
}
function withAlpha(hex, alpha) {
	const n = hex.replace("#", "");
	return `rgba(${Number.parseInt(n.slice(0, 2), 16)}, ${Number.parseInt(n.slice(2, 4), 16)}, ${Number.parseInt(n.slice(4, 6), 16)}, ${alpha})`;
}
function paintPlate(ctx, plate, w, h) {
	if (plate === "ink") {
		const glow = ctx.createRadialGradient(w / 2, h * .46, w * .08, w / 2, h / 2, w * .75);
		glow.addColorStop(0, "#2c261f");
		glow.addColorStop(1, "#100e0c");
		ctx.fillStyle = glow;
		ctx.fillRect(0, 0, w, h);
		return;
	}
	if (plate === "newsprint") {
		ctx.fillStyle = "#f3ecdf";
		ctx.fillRect(0, 0, w, h);
		ctx.fillStyle = "rgba(22, 19, 15, 0.07)";
		const step = Math.max(10, Math.round(w / 70));
		const radius = Math.max(1.1, w / 420);
		for (let y = step; y < h; y += step) {
			const offset = y / step % 2 === 0 ? step : step * 1.5;
			for (let x = offset; x < w; x += step * 2) {
				ctx.beginPath();
				ctx.arc(x, y, radius, 0, Math.PI * 2);
				ctx.fill();
			}
		}
		return;
	}
	if (plate === "split") {
		ctx.fillStyle = "#16130f";
		ctx.fillRect(0, 0, w / 2, h);
		ctx.fillStyle = "#f3ecdf";
		ctx.fillRect(w / 2, 0, w / 2, h);
		const bar = Math.max(8, w * .014);
		ctx.fillStyle = "#ff4d1c";
		ctx.fillRect(w / 2 - bar / 2, 0, bar, h);
		return;
	}
	ctx.fillStyle = "#ff4d1c";
	ctx.fillRect(0, 0, w, h);
	const margin = w * .055;
	ctx.strokeStyle = "#16130f";
	ctx.lineWidth = Math.max(10, w * .02);
	ctx.strokeRect(margin, margin, w - margin * 2, h - margin * 2);
}
function paintBlock(ctx, input, id, raw, nx, ny, w, h) {
	const ghost = input.editing && raw.trim().length === 0;
	const source = ghost ? id === "top" ? "Top text" : "Bottom text" : raw.trim();
	if (!source) return null;
	const shown = (input.uppercase ? source.toUpperCase() : source).replace(/\s+/g, " ").trim();
	if (!shown) return null;
	const scale = w / 1e3;
	const size = Math.max(14, input.fontSize * scale);
	const maxWidth = clamp$1(Math.min(nx, 1 - nx) * 2 * w - w * .06, w * .3, w * .9);
	ctx.font = `400 ${size}px Anton, "Arial Black", Impact, sans-serif`;
	if ("letterSpacing" in ctx) ctx.letterSpacing = `${Math.max(0, size * .015)}px`;
	ctx.textAlign = "center";
	ctx.textBaseline = "middle";
	const lines = wrapLines(ctx, shown, maxWidth);
	const lineHeight = size * 1.12;
	const blockHeight = lines.length * lineHeight;
	let blockWidth = 0;
	for (const line of lines) blockWidth = Math.max(blockWidth, ctx.measureText(line).width);
	const cx = clamp$1(nx, 0, 1) * w;
	const cy = clamp$1(ny, 0, 1) * h;
	ctx.lineJoin = "round";
	ctx.miterLimit = 2;
	ctx.lineWidth = Math.max(0, input.outline * scale * 2);
	ctx.fillStyle = withAlpha(input.fill, ghost ? .45 : 1);
	ctx.strokeStyle = withAlpha(input.stroke, ghost ? .55 : 1);
	lines.forEach((line, index) => {
		const ly = cy - blockHeight / 2 + lineHeight * index + lineHeight / 2;
		if (input.outline > 0) ctx.strokeText(line, cx, ly);
		ctx.fillText(line, cx, ly);
	});
	if (input.editing && input.active === id) {
		ctx.save();
		ctx.strokeStyle = "#ff4d1c";
		ctx.lineWidth = Math.max(2, scale * 2);
		ctx.setLineDash([scale * 8, scale * 6]);
		const pad = size * .2;
		ctx.strokeRect(cx - blockWidth / 2 - pad, cy - blockHeight / 2 - pad, blockWidth + pad * 2, blockHeight + pad * 2);
		ctx.restore();
	}
	return {
		id,
		left: cx - blockWidth / 2,
		top: cy - blockHeight / 2,
		width: blockWidth,
		height: blockHeight,
		cx: cx / w,
		cy: cy / h
	};
}
function renderMeme(canvas, input) {
	const { w, h } = canvasSize(input.plate ? null : input.image);
	if (canvas.width !== w) canvas.width = w;
	if (canvas.height !== h) canvas.height = h;
	const ctx = canvas.getContext("2d");
	if (!ctx) return [];
	ctx.clearRect(0, 0, w, h);
	ctx.imageSmoothingEnabled = true;
	ctx.imageSmoothingQuality = "high";
	if (input.image && !input.plate) ctx.drawImage(input.image, 0, 0, w, h);
	else paintPlate(ctx, input.plate ?? "ink", w, h);
	ctx.save();
	ctx.beginPath();
	ctx.rect(0, 0, w, h);
	ctx.clip();
	const boxes = [paintBlock(ctx, input, "top", input.topText, input.topX, input.topY, w, h), paintBlock(ctx, input, "bottom", input.bottomText, input.bottomX, input.bottomY, w, h)].filter((box) => box !== null);
	ctx.restore();
	return boxes;
}
function hitTest(boxes, px, py, pad, prefer) {
	const hits = boxes.filter((box) => px >= box.left - pad && px <= box.left + box.width + pad && py >= box.top - pad && py <= box.top + box.height + pad);
	if (hits.length === 0) return null;
	return hits.find((box) => box.id === prefer) ?? hits[hits.length - 1];
}
function downloadMeme(input) {
	const canvas = document.createElement("canvas");
	renderMeme(canvas, {
		...input,
		editing: false,
		active: null
	});
	const href = canvas.toDataURL("image/png");
	const link = document.createElement("a");
	link.href = href;
	link.download = "caption-press.png";
	document.body.appendChild(link);
	link.click();
	link.remove();
}
function clamp(n, min, max) {
	return Math.min(max, Math.max(min, n));
}
function oppositeInk(fill, stroke) {
	if (fill !== stroke) return stroke;
	return fill === "ink" ? "paper" : "ink";
}
function MemeStudio() {
	const [editor, setEditor] = (0, import_react.useState)(INITIAL_EDITOR);
	const [upload, setUpload] = (0, import_react.useState)(null);
	const [image, setImage] = (0, import_react.useState)(null);
	const [active, setActive] = (0, import_react.useState)("top");
	const [error, setError] = (0, import_react.useState)("");
	const [saved, setSaved] = (0, import_react.useState)(false);
	const [fontTick, setFontTick] = (0, import_react.useState)(0);
	const [dropOver, setDropOver] = (0, import_react.useState)(false);
	const [hydrated, setHydrated] = (0, import_react.useState)(false);
	const canvasRef = (0, import_react.useRef)(null);
	const boxesRef = (0, import_react.useRef)([]);
	const dragRef = (0, import_react.useRef)(null);
	const dropDepth = (0, import_react.useRef)(0);
	const uploadUrl = (0, import_react.useRef)(null);
	const topRef = (0, import_react.useRef)(null);
	const bottomRef = (0, import_react.useRef)(null);
	const topFieldId = (0, import_react.useId)();
	const bottomFieldId = (0, import_react.useId)();
	const template = findTemplate(editor.templateId);
	const plate = !upload && template.kind === "plate" ? template.id : null;
	const src = upload?.url ?? (template.kind === "photo" ? template.src : null);
	const ready = src ? image !== null : true;
	(0, import_react.useEffect)(() => {
		const savedState = readSaved();
		if (savedState) setEditor(savedState);
		setHydrated(true);
	}, []);
	(0, import_react.useEffect)(() => {
		if (!hydrated) return;
		writeSaved(editor);
	}, [editor, hydrated]);
	(0, import_react.useEffect)(() => {
		const kick = () => setFontTick((n) => n + 1);
		document.fonts.ready.then(kick).catch(kick);
		document.fonts.addEventListener("loadingdone", kick);
		return () => document.fonts.removeEventListener("loadingdone", kick);
	}, []);
	(0, import_react.useEffect)(() => {
		const blockNavigation = (event) => {
			if ([...event.dataTransfer?.items ?? []].some((item) => item.kind === "file")) event.preventDefault();
		};
		window.addEventListener("dragover", blockNavigation);
		window.addEventListener("drop", blockNavigation);
		return () => {
			window.removeEventListener("dragover", blockNavigation);
			window.removeEventListener("drop", blockNavigation);
		};
	}, []);
	(0, import_react.useEffect)(() => {
		return () => {
			if (uploadUrl.current) URL.revokeObjectURL(uploadUrl.current);
		};
	}, []);
	(0, import_react.useEffect)(() => {
		if (!saved) return;
		const timer = window.setTimeout(() => setSaved(false), 1600);
		return () => window.clearTimeout(timer);
	}, [saved]);
	(0, import_react.useEffect)(() => {
		if (!src) {
			setImage(null);
			return;
		}
		let cancel = false;
		const next = new Image();
		if (!src.startsWith("blob:")) next.crossOrigin = "anonymous";
		next.onload = () => {
			if (cancel) return;
			setImage(next);
			setError("");
		};
		next.onerror = () => {
			if (cancel) return;
			setImage(null);
			setError("Couldn't load that image. Try a JPG or PNG.");
		};
		next.src = src;
		return () => {
			cancel = true;
		};
	}, [src]);
	(0, import_react.useEffect)(() => {
		const canvas = canvasRef.current;
		if (!canvas || src && !image) return;
		boxesRef.current = renderMeme(canvas, renderInput(true));
	}, [
		editor,
		image,
		plate,
		src,
		active,
		fontTick
	]);
	function renderInput(editing) {
		return {
			image: plate ? null : image,
			plate,
			topText: editor.top,
			bottomText: editor.bottom,
			topX: editor.topX,
			topY: editor.topY,
			bottomX: editor.bottomX,
			bottomY: editor.bottomY,
			fontSize: editor.fontSize,
			outline: editor.outline,
			fill: INK_HEX[editor.fill],
			stroke: INK_HEX[editor.stroke],
			uppercase: editor.uppercase,
			editing,
			active: editing ? active : null
		};
	}
	function pointOf(event) {
		const canvas = canvasRef.current;
		const rect = event.currentTarget.getBoundingClientRect();
		const width = rect.width || 1;
		const height = rect.height || 1;
		return {
			px: (event.clientX - rect.left) / width * (canvas?.width ?? 1),
			py: (event.clientY - rect.top) / height * (canvas?.height ?? 1)
		};
	}
	function onPointerDown(event) {
		const canvas = canvasRef.current;
		if (!canvas) return;
		const point = pointOf(event);
		const pad = Math.max(36, canvas.width * .04);
		const hit = hitTest(boxesRef.current, point.px, point.py, pad, active);
		if (!hit) return;
		event.currentTarget.setPointerCapture(event.pointerId);
		dragRef.current = {
			id: hit.id,
			ox: hit.cx - point.px / canvas.width,
			oy: hit.cy - point.py / canvas.height
		};
		setActive(hit.id);
	}
	function onPointerMove(event) {
		const canvas = canvasRef.current;
		if (!canvas) return;
		const point = pointOf(event);
		const drag = dragRef.current;
		if (!drag) {
			const pad = Math.max(36, canvas.width * .04);
			const hit = hitTest(boxesRef.current, point.px, point.py, pad, active);
			canvas.style.cursor = hit ? "grab" : "default";
			return;
		}
		canvas.style.cursor = "grabbing";
		const x = clamp(point.px / canvas.width + drag.ox, .04, .96);
		const y = clamp(point.py / canvas.height + drag.oy, .05, .95);
		setEditor((state) => {
			if (drag.id === "top") {
				if (state.topX === x && state.topY === y) return state;
				return {
					...state,
					topX: x,
					topY: y,
					layout: null
				};
			}
			if (state.bottomX === x && state.bottomY === y) return state;
			return {
				...state,
				bottomX: x,
				bottomY: y,
				layout: null
			};
		});
	}
	function onPointerUp(event) {
		dragRef.current = null;
		if (event.currentTarget.hasPointerCapture(event.pointerId)) event.currentTarget.releasePointerCapture(event.pointerId);
		event.currentTarget.style.cursor = "default";
	}
	function onDoubleClick(event) {
		const canvas = canvasRef.current;
		if (!canvas) return;
		const point = pointOf(event);
		const hit = hitTest(boxesRef.current, point.px, point.py, Math.max(36, canvas.width * .04), active);
		if (!hit) return;
		(hit.id === "top" ? topRef : bottomRef).current?.focus();
	}
	function takeFile(file) {
		if (!file) return;
		if (!file.type.startsWith("image/")) {
			setError("That file isn't an image.");
			return;
		}
		if (uploadUrl.current) URL.revokeObjectURL(uploadUrl.current);
		const url = URL.createObjectURL(file);
		uploadUrl.current = url;
		setUpload({
			url,
			name: file.name
		});
		setError("");
	}
	function setFill(fill) {
		setEditor((state) => ({
			...state,
			fill,
			stroke: oppositeInk(fill, state.stroke)
		}));
	}
	function setStroke(stroke) {
		setEditor((state) => ({
			...state,
			stroke,
			fill: oppositeInk(stroke, state.fill)
		}));
	}
	function onDownload() {
		if (!ready) return;
		try {
			downloadMeme(renderInput(false));
			setSaved(true);
			setError("");
		} catch {
			setError("Couldn't export that image.");
		}
	}
	const blurb = editor.layout ? LAYOUT_LIST.find((item) => item.id === editor.layout)?.blurb : "Custom size and placement";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-paper text-ink",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "sticky top-0 z-20 border-b border-ink/10 bg-paper/90 backdrop-blur-md",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-6xl items-center justify-between gap-3 px-4 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "truncate font-display text-2xl leading-none tracking-wide sm:text-4xl",
							children: "CAPTION PRESS"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 truncate text-sm text-muted",
							children: "Top line. Bottom line. Done."
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex shrink-0 items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							"aria-label": "Reset text and layout",
							onClick: () => setEditor((state) => resetEditor(state)),
							className: "inline-flex h-11 items-center gap-2 rounded-md px-3 text-sm font-semibold text-ink transition-colors duration-200 hover:bg-paper-deep",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, {
								className: "size-4",
								"aria-hidden": "true"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "hidden sm:inline",
								children: "Reset"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: onDownload,
							disabled: !ready,
							className: "inline-flex h-11 items-center gap-2 rounded-md bg-accent px-3 text-sm font-semibold text-ink transition-opacity duration-200 hover:opacity-90 disabled:opacity-40 sm:px-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {
								className: "size-4",
								"aria-hidden": "true"
							}), saved ? "Saved" : "Download"]
						})]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "mx-auto grid w-full min-w-0 max-w-6xl grid-cols-1 gap-6 px-4 py-5 lg:grid-cols-[minmax(0,1.25fr)_minmax(20rem,0.8fr)] lg:items-start lg:px-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "min-w-0",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative rounded-lg bg-ink p-2 shadow-lift",
							onDragEnter: (event) => {
								event.preventDefault();
								dropDepth.current += 1;
								setDropOver(true);
							},
							onDragOver: (event) => event.preventDefault(),
							onDragLeave: () => {
								dropDepth.current -= 1;
								if (dropDepth.current <= 0) {
									dropDepth.current = 0;
									setDropOver(false);
								}
							},
							onDrop: (event) => {
								event.preventDefault();
								dropDepth.current = 0;
								setDropOver(false);
								takeFile(event.dataTransfer.files?.[0]);
							},
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "pointer-events-none absolute top-1 left-1 size-1 bg-accent",
									"aria-hidden": "true"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "pointer-events-none absolute top-1 right-1 size-1 bg-accent",
									"aria-hidden": "true"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "pointer-events-none absolute bottom-1 left-1 size-1 bg-accent",
									"aria-hidden": "true"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "pointer-events-none absolute right-1 bottom-1 size-1 bg-accent",
									"aria-hidden": "true"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
									ref: canvasRef,
									width: 1080,
									height: 1080,
									"aria-label": `Meme preview. Top: ${editor.top || "empty"}. Bottom: ${editor.bottom || "empty"}.`,
									onPointerDown,
									onPointerMove,
									onPointerUp,
									onPointerCancel: onPointerUp,
									onDoubleClick,
									className: "meme-canvas rounded-md"
								}),
								dropOver ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "absolute inset-2 grid place-items-center rounded-md bg-ink/80",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-display text-4xl tracking-wide text-paper",
										children: "DROP IT"
									})
								}) : null
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-sm text-muted",
							children: "Drag either line. Double-tap a line to edit it."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-baseline justify-between gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "text-sm font-semibold tracking-wide uppercase",
									children: "Layout"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "truncate text-sm text-muted",
									children: blurb
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-2 flex w-full min-w-0 gap-2 overflow-x-auto pb-1",
								children: LAYOUT_LIST.map((layout) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									"aria-pressed": editor.layout === layout.id,
									onClick: () => setEditor((state) => applyLayout(state, layout.id)),
									className: cn("h-11 shrink-0 rounded-full px-4 text-sm font-semibold transition-colors duration-200", editor.layout === layout.id ? "bg-ink text-paper" : "bg-paper text-ink shadow-border hover:bg-paper-deep"),
									children: layout.label
								}, layout.id))
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-baseline justify-between gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "text-sm font-semibold tracking-wide uppercase",
										children: "Picture"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "truncate text-sm text-muted",
										children: upload ? upload.name : "Or drop one on the frame"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-2 flex w-full min-w-0 gap-2 overflow-x-auto pb-1",
									children: [[
										"cat",
										"meeting",
										"diner",
										"orbit",
										"ink",
										"newsprint",
										"split",
										"signal"
									].map((id) => {
										const item = findTemplate(id);
										const selected = !upload && editor.templateId === item.id;
										return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											"aria-pressed": selected,
											"aria-label": item.name,
											onClick: () => {
												setUpload(null);
												if (uploadUrl.current) {
													URL.revokeObjectURL(uploadUrl.current);
													uploadUrl.current = null;
												}
												setEditor((state) => ({
													...state,
													templateId: item.id
												}));
											},
											className: cn("w-20 shrink-0 rounded-sm p-1 text-left", selected ? "bg-ink text-paper" : "text-ink"),
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "block aspect-square overflow-hidden rounded-sm outline outline-1 -outline-offset-1 outline-ink/15",
												children: item.kind === "photo" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
													src: item.src,
													alt: "",
													draggable: false,
													className: "size-full object-cover"
												}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlateThumb, { id: item.id })
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "mt-1 block truncate text-xs font-medium",
												children: item.name
											})]
										}, item.id);
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "relative flex w-20 shrink-0 cursor-pointer flex-col items-center justify-center gap-1 rounded-sm bg-ink p-1 text-center text-xs font-semibold text-paper",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImagePlus, {
												className: "size-5",
												"aria-hidden": "true"
											}),
											"Upload",
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												type: "file",
												accept: "image/png,image/jpeg,image/webp,image/gif",
												className: "absolute inset-0 cursor-pointer opacity-0",
												onChange: (event) => {
													takeFile(event.target.files?.[0]);
													event.target.value = "";
												}
											})
										]
									})]
								}),
								error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									role: "alert",
									className: "mt-2 text-sm font-medium text-accent",
									children: error
								}) : null
							]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
					className: "studio-panel flex min-w-0 flex-col gap-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-sm font-semibold tracking-wide uppercase",
								children: "The lines"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								htmlFor: topFieldId,
								className: "flex flex-col gap-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm font-medium",
									children: "Top line"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									ref: topRef,
									id: topFieldId,
									value: editor.top,
									maxLength: 180,
									placeholder: "When it finally works",
									onFocus: () => setActive("top"),
									onChange: (event) => setEditor((state) => ({
										...state,
										top: event.target.value
									})),
									className: cn("h-12 w-full rounded-md bg-paper px-3 text-base text-ink shadow-border outline-none placeholder:text-muted/70", active === "top" ? "ring-2 ring-accent" : "focus-visible:ring-2 focus-visible:ring-accent")
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								htmlFor: bottomFieldId,
								className: "flex flex-col gap-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm font-medium",
									children: "Bottom line"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									ref: bottomRef,
									id: bottomFieldId,
									value: editor.bottom,
									maxLength: 180,
									placeholder: "And nobody saw it",
									onFocus: () => setActive("bottom"),
									onChange: (event) => setEditor((state) => ({
										...state,
										bottom: event.target.value
									})),
									className: cn("h-12 w-full rounded-md bg-paper px-3 text-base text-ink shadow-border outline-none placeholder:text-muted/70", active === "bottom" ? "ring-2 ring-accent" : "focus-visible:ring-2 focus-visible:ring-accent")
								})]
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-sm font-semibold tracking-wide uppercase",
								children: "Type"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
								label: "Font size",
								value: editor.fontSize,
								min: 20,
								max: 130,
								onChange: (fontSize) => setEditor((state) => ({
									...state,
									fontSize,
									layout: null
								}))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
								label: "Outline",
								value: editor.outline,
								min: 0,
								max: 28,
								onChange: (outline) => setEditor((state) => ({
									...state,
									outline,
									layout: null
								}))
							}),
							editor.outline === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted",
								children: "No outline — busy photos will swallow the words."
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								"aria-pressed": editor.uppercase,
								onClick: () => setEditor((state) => ({
									...state,
									uppercase: !state.uppercase,
									layout: null
								})),
								className: cn("h-11 rounded-md px-4 text-sm font-semibold transition-colors duration-200", editor.uppercase ? "bg-ink text-paper" : "bg-paper text-ink shadow-border"),
								children: editor.uppercase ? "ALL CAPS" : "As typed"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Swatches, {
								label: "Fill",
								value: editor.fill,
								onChange: setFill
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Swatches, {
								label: "Outline color",
								value: editor.stroke,
								onChange: setStroke
							})
						]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
				className: "mx-auto max-w-6xl px-4 pb-10 text-sm text-muted lg:px-6",
				children: "Drag the lines. Download a PNG. Nothing leaves this page."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "sr-only",
				"aria-live": "polite",
				children: saved ? "Image downloaded." : ""
			})
		]
	});
}
function Slider({ label, value, min, max, onChange }) {
	const id = (0, import_react.useId)();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-1",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-baseline justify-between",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
				htmlFor: id,
				className: "text-sm font-medium",
				children: label
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-sm font-semibold tabular-nums",
				children: value
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			id,
			type: "range",
			min,
			max,
			step: 1,
			value,
			"aria-valuetext": `${value}`,
			onChange: (event) => onChange(Number(event.target.value)),
			className: "h-11 w-full cursor-pointer accent-ink"
		})]
	});
}
function Swatches({ label, value, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center justify-between gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-sm font-medium",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex gap-2",
			children: INKS.map((ink) => {
				const selected = value === ink.id;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-label": `${label} ${ink.label}`,
					"aria-pressed": selected,
					onClick: () => onChange(ink.id),
					className: cn("size-11 rounded-full shadow-border", SWATCH_CLASS[ink.id], selected && (ink.id === "signal" ? "ring-2 ring-ink ring-offset-2 ring-offset-paper" : "ring-2 ring-accent ring-offset-2 ring-offset-paper"))
				}, ink.id);
			})
		})]
	});
}
function PlateThumb({ id }) {
	if (id === "ink") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "block size-full bg-ink-soft" });
	if (id === "newsprint") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "block size-full bg-paper" });
	if (id === "signal") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "block size-full bg-accent" });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: "flex size-full",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-full w-1/2 bg-ink" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-full w-1 bg-accent" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-full flex-1 bg-paper" })
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MemeStudio, {});
}
//#endregion
export { Home as component };
